<?php

// mysql username
define('DB_USER', 'ivaninbox');

// mysql password
define('DB_PASSWORD', 'ivaninbox_wp_1');

// MySQL-server
define('DB_HOST', 'localhost');

// name of database
define('DB_NAME', 'ivaninbox_wp_1');

// name of competition
define('COMP_NAME', 'gps');

// google maps api-key
define('GMAPS_APIKEY', 'AIzaSyDGjRFvMzZpyW1Dva4_6WWqcVF1NyMS2qE');

?>